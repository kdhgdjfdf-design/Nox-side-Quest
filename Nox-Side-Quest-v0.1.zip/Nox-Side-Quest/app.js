const STORAGE_KEY = "nox-side-quest-v1";
const defaultState = { xp: 0, completed: [], activity: [], notes: {} };
let state = loadState();
const $ = (id) => document.getElementById(id);

function loadState() {
  try { return { ...defaultState, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") }; }
  catch { return { ...defaultState }; }
}
function saveState() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function render() {
  $("xpValue").textContent = state.xp;
  const progress = state.xp % 100;
  $("xpProgress").style.width = `${progress}%`;
  $("xpNext").textContent = `${progress} / 100`;
  $("xpCaption").textContent = state.xp ? "استمر في اكتشاف أشياء جديدة" : "ابدأ أول مهمة لتجميع الخبرة";
  $("todayLabel").textContent = new Intl.DateTimeFormat("ar", { weekday: "long", day: "numeric", month: "short" }).format(new Date());
  $("emptyState").hidden = state.activity.length > 0;
  $("activityList").innerHTML = state.activity.map(item =>
    `<li><span>${escapeHtml(item.title)}</span><span>+${item.xp} XP</span></li>`
  ).join("");
  $("startQuest").textContent = state.completed.includes("german-001") ? "أُنجزت المهمة ✓" : "ابدأ المهمة ←";
  $("startQuest").disabled = state.completed.includes("german-001");
  $("startQuest").style.opacity = state.completed.includes("german-001") ? ".65" : "1";
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  setTimeout(() => $("toast").classList.remove("show"), 2300);
}

$("startQuest").addEventListener("click", () => {
  if (state.completed.includes("german-001")) return;
  $("questDialog").showModal();
});
$("completeQuest").addEventListener("click", () => {
  if (state.completed.includes("german-001")) return;
  const note = $("reflection").value.trim();
  state.completed.push("german-001");
  state.xp += 25;
  state.notes["german-001"] = note;
  state.activity.unshift({ title: "أول خمس كلمات ألمانية", xp: 25, date: new Date().toISOString() });
  saveState();
  render();
  $("questDialog").close();
  toast("أحسنت! أضفنا 25 نقطة خبرة ✦");
});
$("interestGrid").addEventListener("click", (event) => {
  const card = event.target.closest("[data-category]");
  if (!card) return;
  const names = {
    languages: "اللغات", mind: "الذكاء والمنطق", faith: "المعرفة الإسلامية",
    medicine: "عالم الطب", tech: "التقنية", creative: "الإبداع", life: "مهارات الحياة"
  };
  toast(`قريبًا: مهام ${names[card.dataset.category]}`);
});

let deferredPrompt = null;
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  deferredPrompt = event;
  $("installBtn").hidden = false;
});
$("installBtn").addEventListener("click", async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  $("installBtn").hidden = true;
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
render();
